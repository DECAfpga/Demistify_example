void abort()
{
	while(1);
}

void exit(int rc)
{
	while(1);
}


#ifndef HEXDUMP_H
#define HEXDUMP_H

void hexdump(char *p,int l);

#endif


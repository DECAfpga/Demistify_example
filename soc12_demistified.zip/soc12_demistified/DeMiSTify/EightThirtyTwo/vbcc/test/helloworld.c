/* Simulation time:
--stop-time=500us
*/

#include "uart.h"

int main(int argc,char **argv)
{
	puts("Hello world!\n");
	return(-1);
}




/* Machine generated file. DON'T TOUCH ME! */


#include "dt.h"

#undef DTTTYPE
#define DTTTYPE dt11t
#undef DTFTYPE
#define DTFTYPE dt11f
dt11t dtcnv11f(dt11f
#include "dtswap32f.c"
dt11f dtcnv11t(dt11t
#include "dtswap32t.c"
#undef DTTTYPE
#define DTTTYPE dt12t
#undef DTFTYPE
#define DTFTYPE dt12f
dt12t dtcnv12f(dt12f
#include "dtswap64f.c"
dt12f dtcnv12t(dt12t
#include "dtswap64t.c"
#undef DTTTYPE
#define DTTTYPE dt13t
#undef DTFTYPE
#define DTFTYPE dt13f
dt13t dtcnv13f(dt13f
#include "dtswap64f.c"
dt13f dtcnv13t(dt13t
#include "dtswap64t.c"
